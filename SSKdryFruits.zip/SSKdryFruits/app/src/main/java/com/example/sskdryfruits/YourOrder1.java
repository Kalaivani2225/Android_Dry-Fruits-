package com.example.sskdryfruits;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class YourOrder1 extends AppCompatActivity {

    ImageView imageview;
    TextView txtdryfruit,txtprice;
    Button placeorderbtn;
    String fruits,price1;
    int img;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_order1);

        imageview = (ImageView)findViewById(R.id.imageyourorder);
        txtprice = (TextView)findViewById(R.id.amntyouorder);
        txtdryfruit =(TextView)findViewById(R.id.txtyourorder);
        placeorderbtn =(Button)findViewById(R.id.placeorderyour);

        fruits = getIntent().getStringExtra("txtdryfruit");
        price1=getIntent().getStringExtra("txtprice");
        img=getIntent().getIntExtra("imageview", R.drawable.walnut);
        txtdryfruit.setText(fruits);
        txtprice.setText(price1);
        imageview.setImageResource(img);


    }
}
