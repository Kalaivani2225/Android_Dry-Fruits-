package com.example.sskdryfruits;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Payment_details extends AppCompatActivity {
EditText edtname,edtaddress,edtnumber;
Button sumbitbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_details);

        edtname =(EditText)findViewById(R.id.nameforpayment);
        edtaddress =(EditText)findViewById(R.id.addressforpayment1);
        edtnumber =(EditText)findViewById(R.id.mobileno);
        sumbitbtn =(Button)findViewById(R.id.submit_payment1);

        sumbitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Order placed",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Payment_details.this,Payment_final.class);
                startActivity(intent);
            }
        });
    }
}
