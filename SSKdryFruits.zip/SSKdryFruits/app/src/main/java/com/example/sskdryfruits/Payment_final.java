package com.example.sskdryfruits;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class Payment_final extends AppCompatActivity {
    RadioButton continuebtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_final);

        continuebtn =(RadioButton) findViewById(R.id.continuepurchase);

        continuebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Intent are used for communicating between the Application components and it also provides the connectivity between two apps.
                // For example: Intent facilitate you to redirect your activity to another activity on occurrence of any event
                Intent intent = new Intent(Payment_final.this,MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);//this term is used for once click to move and back again did't come previous activity

                startActivity(intent);
            }
        });
    }
}
