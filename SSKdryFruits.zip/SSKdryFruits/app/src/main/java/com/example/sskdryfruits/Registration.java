package com.example.sskdryfruits;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    DatabaseSSkdryfruit databasessk;
    EditText nametxt,emailtxt,passwordtxt,confirmpasstxt;
    Button register_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        databasessk = new DatabaseSSkdryfruit(this);

        nametxt=(EditText)findViewById(R.id.nameedtregister);
      emailtxt =(EditText)findViewById(R.id.emailedtregister);
       passwordtxt=(EditText)findViewById(R.id.passwordedtregister);
       confirmpasstxt=(EditText)findViewById(R.id.confirmedtpassregister);
      register_btn =(Button) findViewById(R.id.registerpgbtn);

      register_btn.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              String namereg=nametxt.getText().toString();
              String emailreg=emailtxt.getText().toString();
              String passwordreg=passwordtxt.getText().toString();
              String confrirmpassreg=confirmpasstxt.getText().toString();
              if (namereg.equals("")||emailreg.equals("")||passwordreg.equals("")||confrirmpassreg.equals(""))
              {
                  Toast.makeText(getApplicationContext(),"Fields are empty",Toast.LENGTH_LONG).show();
              }
              else if (passwordreg.equals(confrirmpassreg)) {
                      Boolean chkemail = databasessk.chkemail(emailreg);
                      if (chkemail == true) {
                          Boolean insert = databasessk.insert(emailreg, passwordreg);
                          if (insert == true) {
                              Toast.makeText(getApplicationContext(), "Registered successfully", Toast.LENGTH_LONG).show();
                              Intent intent = new Intent(Registration.this,login.class);  //Intent are used for communicating between the Application components and it also provides the connectivity between two apps.
                              // For example: Intent facilitate you to redirect your activity to another activity on occurrence of any event
                              startActivity(intent);

                          }
                      } else {
                          Toast.makeText(getApplicationContext(), "email is Already exists", Toast.LENGTH_LONG).show();
                      }
                  }
                      else {

                      Toast.makeText(getApplicationContext(), "password do not match", Toast.LENGTH_LONG).show();

                  }
                       //if (passwordreg.equals("")||confrirmpassreg.equals(""))
                     //  {
                    //       Toast.makeText(getApplicationContext(),"password & confirm password not complete",Toast.LENGTH_LONG).show();

             // }

          }
      });

    }
}
