package com.example.sskdryfruits;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import java.util.ArrayList;
import java.util.zip.Inflater;


/**
 * A simple {@link Fragment} subclass.

 */
public class Home extends Fragment {
    ViewFlipper v_flipper;
    GridView gridView;
    String[]  dryfruitnames = {"Cashew","Pista","Walnut","Badam","Ground nut","Dates"};
    Integer[] dryfruitimages ={R.drawable.cashew,R.drawable.pista1,R.drawable.walnut,
            R.drawable.patam1,R.drawable.groundnut,R.drawable.dates};//this is used forDisplaying image for Home



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_home,container,false);
        gridView = rootView.findViewById(R.id.gridview);

        int images[] = {R.drawable.dates, R.drawable.batam, R.drawable.saffron,R.drawable.pista1};
        v_flipper = rootView.findViewById(R.id.vFlipper);

        for(int image: images){
            flipperImage(image);
        }

HomeAdapter adapter = new HomeAdapter(getActivity(),dryfruitnames,dryfruitimages);
//this is used for the image adapter must have name,price and image
        gridView.setAdapter(adapter);
        //this coding is used for images displayed in gridview

        return rootView;
    }
    public String toString(){
        return "all";
    }

    public  void flipperImage(int image){
        ImageView imageView = new ImageView(getActivity());
        imageView.setBackgroundResource(image);

        v_flipper.addView(imageView);
        v_flipper.setFlipInterval(2000);
        v_flipper.setAutoStart(true);

        v_flipper.setInAnimation(getActivity(), android.R.anim.slide_in_left);
        v_flipper.setOutAnimation(getActivity(), android.R.anim.slide_out_right);
    }
}
