package com.example.sskdryfruits;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class HomeAdapter extends BaseAdapter {

    private Context context;
    private String[] fruitnames;
    public Integer [] fruitimages;

    public HomeAdapter(Context context1,String[] fruitnames1,Integer[] fruitimages1){
        this.context = context1;
        this.fruitnames = fruitnames1;
        this.fruitimages =fruitimages1;
    }

    @Override
    public int getCount() {
        return fruitnames.length;
    }

    @Override
    public Object getItem(int position) {
        return fruitnames[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView==null) {// this is use to Gridview layout this is  layout has showing the details of id
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView= inflater.inflate(R.layout.homeimage,null);
        }
        TextView txtfruitname = (TextView)convertView.findViewById(R.id.txthometxt);
        ImageView txtfruitimage= (ImageView)convertView.findViewById(R.id.imghomeimg);

        txtfruitname.setText(fruitnames[position]);
        txtfruitimage.setImageResource(fruitimages[position]);

        return convertView;
    }
}
