package com.example.sskdryfruits;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DryfruitAdapter extends RecyclerView.Adapter<DryfruitAdapter.ViewHolder> {

   private Context contexts;
   private ArrayList<Dryfruit1>dlist;
   DryfruitAdapter(Context cont, ArrayList<Dryfruit1>list) {
    contexts = cont;
    dlist = list;
}
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {//LayoutInflater is a class used to
                                                                          // instantiate layout XML file into its
                                                                      // corresponding view objects which can be used in Java programs
        LayoutInflater layoutInflater = LayoutInflater.from(contexts);

        View view = layoutInflater.inflate(R.layout.dryfruit_one,parent,false);
        ViewHolder viewholder = new ViewHolder(view);//A RecyclerView. ViewHolder class which caches views associated with
                                                    // the default Preference layouts.

        return viewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
       final Dryfruit1 fruitsitem = dlist.get(position);

       ImageView image1 = holder.itemview;  //The onBind() method is called when the client component
        // binds to the Service for the first time through bindService
       TextView name,price;
       name = holder.item_name;
       price = holder.item_price;

       image1.setImageResource(fruitsitem.getImage());
       name.setText(fruitsitem.getName());
       price.setText(fruitsitem.getPrice());

       holder.itemview.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent =new Intent(contexts,Dryfruits_details.class);
               intent.putExtra("name",fruitsitem.getName());
               intent.putExtra("buynow",fruitsitem.getPrice());
               intent.putExtra("image",fruitsitem.getImage());
               contexts.startActivity(intent);
           }
       });

       holder.item_price.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent(contexts,Dryfruits_details.class);
               intent.putExtra("name",fruitsitem.getName());
               intent.putExtra("buynow",fruitsitem.getPrice());
               intent.putExtra("image",fruitsitem.getImage());
               contexts.startActivity(intent);
           }
       });
    }

    @Override
    public int getItemCount() {
        return dlist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {  //ViewHolder class which caches views associated with the default Preference layouts.
    ImageView itemview;
    TextView item_name,item_price;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            itemview = itemView.findViewById(R.id.datesdryfruit);
            item_name = itemView.findViewById(R.id.itemname1);
            item_price =itemView.findViewById(R.id.itemrs);

        }
    }
}
