package com.example.sskdryfruits;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Payment_CD_details extends AppCompatActivity {

    EditText edtAcname,edtAcno,edtifsc;
    Button btnsubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment__cd_details);

        edtAcname = (EditText)findViewById(R.id.acname);
        edtAcno =(EditText)findViewById(R.id.acno);
        btnsubmit = (Button)findViewById(R.id.paymentsubmit);
        edtifsc =(EditText) findViewById(R.id.ifsccode);

        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Payment_CD_details.this,Payment_details.class);
                startActivity(intent);
            }
        });

    }
}
