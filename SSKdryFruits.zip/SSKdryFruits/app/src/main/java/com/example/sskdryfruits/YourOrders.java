package com.example.sskdryfruits;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class YourOrders extends Fragment {

    RecyclerView recyclerview;
    ArrayList<Dryfruit1>list2;
    DatabhaseAddtocart addtocart;
   public YourOrders()
   {

   }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        addtocart=new DatabhaseAddtocart(requireContext());


        ArrayList<Dryfruit1>list2;
        // Inflate the layout for this fragment


        View rootview= inflater.inflate(R.layout.fragment_your_orders, container, false);
        RecyclerView recyclerview =(RecyclerView)rootview.findViewById(R.id.recyclevieaddtc);
        LinearLayoutManager manager = new LinearLayoutManager(getActivity());


        RecyclerView.LayoutManager rlayoutmanger = manager;
        YourOrdersAdapter yourordersadapter = new YourOrdersAdapter(requireContext(),new ArrayList(addtocart.list1()));
        recyclerview.setAdapter(yourordersadapter);

        recyclerview.setLayoutManager(rlayoutmanger);


        return rootview;
    }

}
