package com.example.sskdryfruits;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class Payment extends AppCompatActivity {

    RadioButton Rdocredit,Rdocashondeliver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        Rdocredit=(RadioButton)findViewById(R.id.credit_debit);//the Radio button used toAndroid RadioButton.
        // RadioButton is a two states button which is either checked or unchecked
        Rdocashondeliver=(RadioButton)findViewById(R.id.cashondelivery);
        Rdocredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent are used for communicating between the Application components and it also provides the connectivity between two apps.
                // For example: Intent facilitate you to redirect your activity to another activity on occurrence of any event

                Intent intent = new Intent(Payment.this,Payment_CD_details.class);
                startActivity(intent);
            }
        });
        Rdocashondeliver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent are used for communicating between the Application components and it also provides the connectivity between two apps.
                // For example: Intent facilitate you to redirect your activity to another activity on occurrence of any event
                Intent intent1 = new Intent(Payment.this,Payment_details.class);
                startActivity(intent1);
            }
        });
    }
}
