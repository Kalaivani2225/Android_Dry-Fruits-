package com.example.sskdryfruits;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;

import android.os.Handler;
import android.transition.Slide;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;

import static com.example.sskdryfruits.R.string.open;

public class MainActivity extends AppCompatActivity
{
    private DrawerLayout drawerLayout;
    Toolbar tb;
    FragmentTransaction fragmentTransaction;    //A FragmentManager manages Fragments in Android,
    // specifically it handles transactions
    // between fragments
    private ActionBarDrawerToggle abdt;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tb = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(tb);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerlayoutmain);
        final NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        abdt = new ActionBarDrawerToggle(this,drawerLayout,tb, open,R.string.close);

        drawerLayout.addDrawerListener(abdt);
        abdt.syncState();
        fragmentTransaction = getSupportFragmentManager().beginTransaction();//.FragmentPagerAdapter. Implementation of PagerAdapter that represents each page as
        // a Fragment that is persistently kept in the fragment manager
        // as long as the user can return to the page
        fragmentTransaction.add(R.id.fragment_container, new Home());
        fragmentTransaction.commit();
        getSupportActionBar().setTitle("SSK DryFruits");


        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.homemenu:
                        fragmentTransaction = getSupportFragmentManager().beginTransaction();
                        fragmentTransaction.replace(R.id.fragment_container, new Home());
                        fragmentTransaction.commit();
                        getSupportActionBar().setTitle("Home");
                        menuItem.setChecked(true);
                        break;
                    case R.id.dryfruitmenu:
                        fragmentTransaction = getSupportFragmentManager().beginTransaction();
                        fragmentTransaction.replace(R.id.fragment_container, new YourOrders());
                        fragmentTransaction.commit();
                        getSupportActionBar().setTitle("YournewOrders");
                        menuItem.setChecked(true);           //A FragmentManager manages Fragments in Android,
                                                      // specifically it handles transactions
                                                              // between fragments
                        break;
                    case R.id.aboutmemenu:
                        fragmentTransaction = getSupportFragmentManager().beginTransaction();
                        fragmentTransaction.replace(R.id.fragment_container, new AboutMe());
                        fragmentTransaction.commit();
                        getSupportActionBar().setTitle("AboutUs");
                        menuItem.setChecked(true);
                        break;
                    case R.id.Yourordermenu:
                        fragmentTransaction = getSupportFragmentManager().beginTransaction();     //A FragmentManager manages Fragments in Android,
                                                                                               // specifically it handles transactions
                                                                                                   // between fragments
                        fragmentTransaction.replace(R.id.fragment_container, new DryFruits());
                        fragmentTransaction.commit();
                        getSupportActionBar().setTitle("DryFruits");
                        menuItem.setChecked(true);
                        break;
                    case R.id.logoutmenu:
                        fragmentTransaction = getSupportFragmentManager().beginTransaction();
                        fragmentTransaction.replace(R.id.fragment_container,new Logout());
                        fragmentTransaction.commit();
                        getSupportActionBar().setTitle("Logout");
                        menuItem.setChecked(true);
                        break;
                }
                drawerLayout.closeDrawer(GravityCompat.START);


                return true;
            }
        });


    }

    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }

    }
}
