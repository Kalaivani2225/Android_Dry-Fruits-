package com.example.sskdryfruits;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabhaseAddtocart extends SQLiteOpenHelper {
    public DatabhaseAddtocart(@Nullable Context context){
        super(context,"cart.db",null,1);
    }
    public void onCreate(SQLiteDatabase database){
        database.execSQL("create table cart1(image integer,fruitname text,price text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {

        database.execSQL("drop table if exists cart1");

    }
public boolean insert(Integer image,String fruitname,String price){
        SQLiteDatabase database = this.getWritableDatabase();
    ContentValues contentValues = new ContentValues();
    contentValues.put("image",image);
    contentValues.put("fruitname",fruitname);
    contentValues.put("price",price);
    long ins = database.insert("cart1",null,contentValues);
    if (ins == -1)
        return false;
    else
        return true;
}

public List<Dryfruit1> list1(){
        SQLiteDatabase database =this.getReadableDatabase();
    Cursor cursor1 =database.rawQuery(" select * from cart1 ",null);
    List<Dryfruit1> list = new ArrayList<Dryfruit1>();
    if (cursor1.getCount()>0) {
        while (cursor1.moveToNext()) {
            String price = cursor1.getString(cursor1.getColumnIndex("price"));
            int image = cursor1.getInt(cursor1.getColumnIndex("image"));
            String fruitname = cursor1.getString(cursor1.getColumnIndex("fruitname"));
            Dryfruit1 yourorder = new Dryfruit1(image,fruitname,price);
            list.add(yourorder);
        }
    }
    return list;
}

}
