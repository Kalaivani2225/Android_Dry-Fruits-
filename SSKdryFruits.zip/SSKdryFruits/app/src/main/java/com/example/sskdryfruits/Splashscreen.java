package com.example.sskdryfruits;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Splashscreen extends AppCompatActivity
{
    private static int splashscreen_time = 3500;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

       new Handler().postDelayed(new Runnable() {   // Handler allows communicating back with UI thread from other background thread
           @Override                             //This is useful in android as android doesn't allow other threads to
                                              // communicate directly with UI thread
           public void run() {

               //Intent are used for communicating between the Application components and it also provides the connectivity between two apps.
               // For example: Intent facilitate you to redirect your activity to another activity on occurrence of any event
               Intent intentsplash = new Intent(Splashscreen.this,Autoimage.class);
               startActivity(intentsplash);
               finish();

           }
       },splashscreen_time);
    }
}
