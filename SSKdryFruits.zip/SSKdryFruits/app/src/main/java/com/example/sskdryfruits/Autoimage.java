package com.example.sskdryfruits;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ViewFlipper;

public class Autoimage extends AppCompatActivity {
    Button signin,signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_autoimage);
        //the signin & signup button can using for front activity touch to next slide means for intent to another activity
        signin = (Button) findViewById(R.id.signin);
        signup =(Button) findViewById(R.id.signup);

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Autoimage.this,login.class);
                startActivity(intent);
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signupintent = new Intent(Autoimage.this,Registration.class);
                startActivity(signupintent);
                Toast.makeText(getApplicationContext(),"Regiteration..",Toast.LENGTH_LONG).show();
            }
        });
    }


    }

