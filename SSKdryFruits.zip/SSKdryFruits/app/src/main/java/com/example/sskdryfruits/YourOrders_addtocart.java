package com.example.sskdryfruits;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class YourOrders_addtocart extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_orders_addtocart);
    }
}
