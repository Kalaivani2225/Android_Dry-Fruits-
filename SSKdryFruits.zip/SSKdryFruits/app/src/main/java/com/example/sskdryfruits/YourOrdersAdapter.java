package com.example.sskdryfruits;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class YourOrdersAdapter extends RecyclerView.Adapter<YourOrdersAdapter.ViewHolder> {

    private Context context1;

    private ArrayList<Dryfruit1>drylist;
    YourOrdersAdapter(Context cont2,ArrayList<Dryfruit1>yourlist){
        context1 = cont2;
        drylist=yourlist;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =LayoutInflater.from(context1);

        View view1 = inflater.inflate(R.layout.activity_your_orders_addtocart,parent,false);
        ViewHolder viewholder = new ViewHolder(view1);
        return viewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final Dryfruit1 fruititem = drylist.get(position);
        ImageView imageView1 = holder.itemview;
        TextView name,price;
        name= holder.item_name;
        price = holder.item_price;

        imageView1.setImageResource(fruititem.getImage());
         name.setText(fruititem.getName());
         price.setText(fruititem.getPrice());

    }

    @Override
    public int getItemCount() {
        return drylist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView itemview;
        TextView item_name,item_price;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            itemview =itemView.findViewById(R.id.imageforaddtocart);
            item_name = itemView.findViewById(R.id.txtforaddtocart);
            item_price = itemView.findViewById(R.id.txt2foraddtocart);


        }
    }
}
