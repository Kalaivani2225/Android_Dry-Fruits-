package com.example.sskdryfruits;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Dryfruits_details extends AppCompatActivity {

    ImageView imageview;
    TextView txtname;
    Button buynowbtn,addtocartbtn;
    String dryfruitname,price;
    int image;
    DatabhaseAddtocart addtocart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dryfruits_details);
        addtocart = new DatabhaseAddtocart(this);


        imageview = (ImageView)findViewById(R.id.imagedetails1);
        txtname = (TextView)findViewById(R.id.fruitname);
        buynowbtn =(Button)findViewById(R.id.buynow1);
        addtocartbtn =(Button)findViewById(R.id.addtocartbtn);
        dryfruitname = getIntent().getStringExtra("name");
        price = getIntent().getStringExtra("buynow");
        image =getIntent().getIntExtra("image",R.drawable.anjeer);
        txtname.setText(dryfruitname);
        buynowbtn.setText(price);
        imageview.setImageResource(image);
        addtocartbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//this add to cart function the button click then stored of database Yourorder activity the only view on order
                boolean insert = addtocart.insert(image,dryfruitname,price);
                Toast.makeText(getApplicationContext(),"Dryfruit on Your Cart",Toast.LENGTH_LONG).show();
            }
        });
        buynowbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//this buynow button click next activity move on...
                Intent intent = new Intent(Dryfruits_details.this,Payment.class);
                startActivity(intent);
            }
        });
    }
}
