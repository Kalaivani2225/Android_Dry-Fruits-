package com.example.sskdryfruits;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ViewFlipper;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class DryFruits extends Fragment {

    RecyclerView recyclerView;
    ArrayList<Dryfruit1> dryfruitlist;
    ViewFlipper viewflipper1;

   public DryFruits(){
       //Required Empty public Constructor
   }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       ArrayList<Dryfruit1>dryfruitList;// list of showing images and details can help the Arraylist the detail insert to display and store on database
        // Inflate the layout for this fragment
        View v1 = inflater.inflate(R.layout.fragment_dry_fruits, container, false);
// view flipper is used to Auto image slide front view Dryfruits showing image with seconds the only used for auto image slide..

        int images1[] = {R.drawable.dates, R.drawable.batam, R.drawable.saffron,R.drawable.pista1,R.drawable.cashew};
        viewflipper1 = v1.findViewById(R.id.vFlipper12);

        for(int image: images1){
            flipperImage(image);
        }

//the dryfruitlist is drawable in recyclelistview this is display the dryfruit items then click to order..
        RecyclerView recyclerView = (RecyclerView) v1.findViewById(R.id.recycleview);
      dryfruitList = new ArrayList<>();
       dryfruitList.add(new Dryfruit1(R.drawable.patam1,"Badam"," 800Rs "));
        dryfruitList.add(new Dryfruit1(R.drawable.saffron,"Saffron","780Rs"));
        dryfruitList.add(new Dryfruit1(R.drawable.peanut,"Peanut","300Rs"));
        dryfruitList.add(new Dryfruit1(R.drawable.pista1,"Pista","600Rs"));
        dryfruitList.add(new Dryfruit1(R.drawable.goldenraisins,"Golden Rasings","150Rs"));
        dryfruitList.add(new Dryfruit1(R.drawable.groundnut,"Groundnut","60Rs"));
        dryfruitList.add(new Dryfruit1(R.drawable.walnut,"Walnut","100Rs"));
        dryfruitList.add(new Dryfruit1(R.drawable.cashew,"Cashew","120Rs"));
        dryfruitList.add(new Dryfruit1(R.drawable.dates,"Dates","140Rs"));
        dryfruitList.add(new Dryfruit1(R.drawable.anjeer,"Anjeer","120Rs"));
//the layout manager is function has get the layout in adapter to put
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());

        RecyclerView.LayoutManager rvlayoutmanager1 = layoutManager;

        DryfruitAdapter adapter = new DryfruitAdapter(requireContext(),dryfruitList);
        recyclerView.setAdapter(adapter);


        recyclerView.setLayoutManager(rvlayoutmanager1);

        return v1;
    }

    private void flipperImage(int image1) {

        ImageView imageview = new ImageView(getActivity());
        imageview.setBackgroundResource(image1);

        viewflipper1.addView(imageview);
        viewflipper1.setFlipInterval(2000);
        viewflipper1.setAutoStart(true);

        viewflipper1.setInAnimation(getActivity(), android.R.anim.slide_in_left);
        viewflipper1.setOutAnimation(getActivity(), android.R.anim.slide_out_right);
    }


}
