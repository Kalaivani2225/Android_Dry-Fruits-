package com.example.sskdryfruits;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class login extends AppCompatActivity {

    EditText usertxt,passworrdtxt1;
    Button continue1btn ;
    DatabaseSSkdryfruit databasessk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databasessk = new DatabaseSSkdryfruit(this);

        usertxt =(EditText)findViewById(R.id.loginedt);
        passworrdtxt1=(EditText)findViewById(R.id.passwordloginedt);
        continue1btn=(Button) findViewById(R.id.continuelogin1);
        continue1btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String email = usertxt.getText().toString();
            String pass = passworrdtxt1.getText().toString();
            Boolean Login = databasessk.Login(email,pass);
                if (email.equals("")|pass.equals("")){
                    Toast.makeText(getApplicationContext(),"Feilds are empty",Toast.LENGTH_LONG).show();

                }
            if (Login == true) {
                Toast.makeText(getApplicationContext(), "Successfully Login", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(login.this,MainActivity.class);//Intent are used for communicating between the Application components and it also provides the connectivity between two apps.
                // For example: Intent facilitate you to redirect your activity to another activity on occurrence of any event
                startActivity(intent);
            }else {
                Toast.makeText(getApplicationContext(), "Wrong email or password", Toast.LENGTH_LONG).show();
            }
            }

        });
    }
}

